###Sitecore security hardening guide Octopus step

Step for Octopus to apply Sitecore security hardening guide. Based on https://grantkillian.wordpress.com/2016/08/15/unified-security-hardening-script-for-sitecore/.



##Usage

Add the step to the Octopus library using step.json. Then upload the package to Octopus. 
Then add the step on your solution's process in Octopus, and fill in the parameters. 

